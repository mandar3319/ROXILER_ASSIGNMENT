Transactions DashBoard for displaying the statistics and the trnasaction with bar chart and pie chart.
